#ifndef WINDOWDLG_H
#define WINDOWDLG_H

#include "DIALOG.h"
#include <registers.h>

extern GUI_CONST_STORAGE GUI_FONT GUI_FontArial32;


WM_HWIN CreateWindow(void);
WM_HWIN CreateTests(void);
WM_HWIN CreateMainWindow(void);

#endif

